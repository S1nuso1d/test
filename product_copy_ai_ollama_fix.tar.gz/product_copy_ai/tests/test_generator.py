from app.config import Settings
from app.schemas import ProductInput
from app.services.generator import generate_product_copy


async def test_generator_returns_source_characteristics(monkeypatch) -> None:
    description = (
        "Прибор описан на основании предоставленных исходных сведений. "
        "Перед публикацией контент-менеджеру следует сверить назначение, "
        "условия эксплуатации, комплект поставки и совместимость с паспортом. "
        "Если такие сведения отсутствуют, их необходимо запросить у производителя. "
    ) * 5
    description = description[:900]

    async def fake_generate_json(self, system_prompt: str, user_prompt: str) -> dict:
        return {
            "seo_title": "Манометр показывающий DM 02 Манотомь",
            "seo_description": description,
            "seo_queries": [
                "манометр показывающий DM 02",
                "манометр Манотомь",
                "манометр для измерения давления",
            ],
            "commercial_block": (
                "Для определения целевой аудитории и задач применения нужно уточнить "
                "условия эксплуатации и назначение по техническому паспорту."
            ),
        }

    monkeypatch.setattr(
        "app.services.generator.LLMClient.generate_json",
        fake_generate_json,
    )
    product = ProductInput(
        name="Манометр показывающий DM 02",
        manufacturer="Манотомь",
        specs={"диапазон измерений": "0–1,6 МПа", "класс точности": "1,5"},
        description="Прибор предназначен для измерения избыточного давления.",
    )

    result = await generate_product_copy(product, Settings())

    assert result.status == "generated"
    assert result.seo_title == "Манометр показывающий DM 02 Манотомь"
    assert result.key_characteristics[0].value == "0–1,6 МПа"
    assert len(result.seo_description or "") == 900


async def test_generator_retries_when_seo_description_is_too_short(monkeypatch) -> None:
    valid_description = (
        "Описание составлено только по предоставленным сведениям о товаре. "
        "Перед публикацией необходимо проверить паспорт, комплект поставки и "
        "дополнительные параметры, которые не были переданы во входных данных. "
    ) * 6
    valid_description = valid_description[:900]
    responses = [
        {
            "seo_title": "Манометр DM 02",
            "seo_description": "Слишком короткое описание.",
            "seo_queries": ["манометр DM 02", "манометр Манотомь", "манометр"],
            "commercial_block": "Назначение следует уточнить по паспорту.",
        },
        {
            "seo_title": "Манометр DM 02",
            "seo_description": valid_description,
            "seo_queries": ["манометр DM 02", "манометр Манотомь", "манометр"],
            "commercial_block": "Назначение следует уточнить по паспорту.",
        },
    ]
    calls = 0

    async def fake_generate_json(self, system_prompt: str, user_prompt: str) -> dict:
        nonlocal calls
        result = responses[calls]
        calls += 1
        return result

    monkeypatch.setattr(
        "app.services.generator.LLMClient.generate_json",
        fake_generate_json,
    )
    product = ProductInput(
        name="Манометр DM 02",
        manufacturer="Манотомь",
        specs={"диапазон измерений": "0–1,6 МПа"},
        description="Манометр для измерения избыточного давления.",
    )

    result = await generate_product_copy(product, Settings())

    assert result.status == "generated"
    assert calls == 2
    assert result.seo_description == valid_description.strip()


async def test_generator_uses_grounded_fallback_after_repeated_short_descriptions(monkeypatch) -> None:
    calls = 0
    captured_prompts: list[str] = []

    async def fake_generate_json(self, system_prompt: str, user_prompt: str) -> dict:
        nonlocal calls
        calls += 1
        captured_prompts.append(user_prompt)
        return {
            "seo_title": "Манометр показывающий DM 02",
            "seo_description": "Манометр DM 02 от Манотомь для измерения давления.",
            "seo_queries": [
                "манометр показывающий DM 02",
                "манометр Манотомь",
                "манометр 0–1,6 МПа",
            ],
            "commercial_block": "Перед подбором следует сверить параметры с паспортом производителя.",
        }

    monkeypatch.setattr(
        "app.services.generator.LLMClient.generate_json",
        fake_generate_json,
    )
    product = ProductInput(
        name="Манометр показывающий DM 02",
        manufacturer="Манотомь",
        specs={
            "диапазон измерений": "0–1,6 МПа",
            "класс точности": "1,5",
            "присоединение": "G1/2",
            "диаметр корпуса": "100 мм",
        },
        description="Прибор предназначен для измерения избыточного давления...",
    )

    result = await generate_product_copy(product, Settings())

    assert calls == 3
    assert "800" in captured_prompts[1]
    assert "950–1050" in captured_prompts[1]
    assert result.status == "generated"
    assert 800 <= len(result.seo_description or "") <= 1200
    assert "0–1,6 МПа" in (result.seo_description or "")
    assert "G1/2" in (result.seo_description or "")
    assert any("безопасному шаблону" in warning for warning in result.warnings)


async def test_generator_does_not_use_fallback_for_other_validation_errors(monkeypatch) -> None:
    calls = 0

    async def fake_generate_json(self, system_prompt: str, user_prompt: str) -> dict:
        nonlocal calls
        calls += 1
        return {
            "seo_title": "",
            "seo_description": "Короткий текст.",
            "seo_queries": ["один запрос"],
            "commercial_block": "Уточните паспортные данные.",
        }

    monkeypatch.setattr(
        "app.services.generator.LLMClient.generate_json",
        fake_generate_json,
    )
    product = ProductInput(
        name="Манометр DM 02",
        specs={"диапазон измерений": "0–1,6 МПа"},
        description="Измерение избыточного давления.",
    )

    try:
        await generate_product_copy(product, Settings())
    except Exception as exc:
        assert "не соответствующий требованиям" in str(exc)
    else:
        raise AssertionError("Expected validation failure")
    assert calls == 3
