from pydantic import ValidationError

from app.config import Settings
from app.schemas import GenerationResponse, ProductCopy, ProductInput
from app.services.description_builder import build_fallback_seo_description
from app.services.guardrails import (
    build_characteristics,
    build_source_text,
    find_missing_fields,
    find_unsupported_numbers,
    has_substantive_product_data,
)
from app.services.llm_client import LLMClient, LLMClientError
from app.services.prompts import SYSTEM_PROMPT, build_user_prompt


class GenerationError(RuntimeError):
    """Raised when safe, schema-compliant product copy cannot be generated."""


def _build_validation_correction(
    issues: list[dict],
    previous_result: dict,
    *,
    attempt: int,
) -> str:
    """Give the model actionable feedback for its next structured response."""
    description = str(previous_result.get("seo_description", ""))
    description_length = len(description)
    description_issue = any(
        issue.get("loc", ()) == ("seo_description",)
        and issue.get("type") == "string_too_short"
        for issue in issues
    )
    if description_issue:
        return (
            f"КРИТИЧЕСКАЯ ОШИБКА: seo_description содержит {description_length} символов, "
            "а требуется от 800 до 1200 включительно. Это повторная попытка "
            f"№{attempt}; не возвращай краткую аннотацию. Перепиши seo_description "
            "объёмом примерно 950–1050 символов. Сделай 6–8 содержательных предложений: "
            "назначение и идентификация товара; все подтверждённые параметры; "
            "пояснение, какие проверки покупатель должен выполнить по диапазону, точности, "
            "присоединению и габаритам (если эти параметры переданы); перечисление "
            "важных сведений, которых нет во входных данных; рекомендация сверить паспорт. "
            "Не придумывай свойства, совместимость, преимущества или условия применения. "
            "Не повторяй фразы ради объёма. Проверь количество символов перед ответом. "
            "Верни полный JSON со всеми обязательными полями. Предыдущая ошибка: "
            + str(issues[:5])
        )
    return (
        "Ответ не прошёл проверку формата или ограничений. Исправь перечисленные проблемы, "
        "сохранив фактическую точность, и верни полный JSON: "
        + str(issues[:5])
    )


async def generate_product_copy(
    product: ProductInput,
    settings: Settings,
) -> GenerationResponse:
    missing_fields = find_missing_fields(product)
    characteristics = build_characteristics(product)

    if not has_substantive_product_data(product):
        return GenerationResponse(
            status="needs_data",
            key_characteristics=characteristics,
            missing_fields=missing_fields,
            warnings=[
                "Недостаточно исходной информации. Укажите название товара и хотя бы "
                "одно содержательное описание или техническую характеристику."
            ],
        )

    client = LLMClient(settings)
    source_text = build_source_text(product)
    correction: str | None = None
    fallback_used = False
    max_attempts = 3

    for attempt in range(max_attempts):
        raw_result = await client.generate_json(
            SYSTEM_PROMPT,
            build_user_prompt(product, correction=correction),
        )
        try:
            draft = ProductCopy.model_validate(raw_result)
        except ValidationError as exc:
            all_validation_issues = exc.errors(include_url=False)
            validation_issues = all_validation_issues[:5]
            only_description_too_short = bool(all_validation_issues) and all(
                issue.get("loc", ()) == ("seo_description",)
                and issue.get("type") == "string_too_short"
                for issue in all_validation_issues
            )

            if attempt < max_attempts - 1:
                correction = _build_validation_correction(
                    validation_issues,
                    raw_result,
                    attempt=attempt + 1,
                )
                continue

            if only_description_too_short:
                fallback_description = build_fallback_seo_description(product)
                if fallback_description:
                    fallback_payload = dict(raw_result)
                    fallback_payload["seo_description"] = fallback_description
                    try:
                        draft = ProductCopy.model_validate(fallback_payload)
                        fallback_used = True
                    except ValidationError:
                        raise GenerationError(
                            "Модель вернула короткое SEO-описание, а безопасный шаблон "
                            "не удалось привести к требованиям 800–1200 символов. "
                            "Добавьте исходные сведения о товаре и повторите запрос."
                        ) from exc
                else:
                    raise GenerationError(
                        "Модель вернула короткое SEO-описание. По имеющимся исходным данным "
                        "не удалось сформировать безопасный текст на 800–1200 символов. "
                        "Добавьте описание или технические характеристики товара."
                    ) from exc
            else:
                raise GenerationError(
                    f"Модель {max_attempts} раза вернула результат, не соответствующий требованиям: "
                    + str(validation_issues)
                ) from exc

        text_to_check = f"{draft.seo_description}\n{draft.commercial_block}"
        unsupported_numbers = find_unsupported_numbers(text_to_check, source_text)
        if not unsupported_numbers:
            warnings = [
                "Сгенерированный текст является черновиком и требует проверки контент-менеджером."
            ]
            if fallback_used:
                warnings.append(
                    "Модель не смогла подготовить SEO-описание нужной длины. Описание сформировано "
                    "по безопасному шаблону на основе входных данных; проверьте его перед публикацией."
                )
            if missing_fields:
                warnings.append(
                    "Часть сведений отсутствует во входных данных; соответствующие пробелы "
                    "должны быть уточнены до публикации."
                )
            return GenerationResponse(
                status="generated",
                seo_title=draft.seo_title,
                seo_description=draft.seo_description,
                key_characteristics=characteristics,
                seo_queries=draft.seo_queries,
                commercial_block=draft.commercial_block,
                missing_fields=missing_fields,
                warnings=warnings,
            )

        correction = (
            "Числовые значения, которых нет в источнике: " + ", ".join(unsupported_numbers)
        )

    raise GenerationError(
        "Не удалось получить текст без неподтверждённых числовых значений. "
        "Попробуйте уточнить исходные данные или повторить запрос."
    )
