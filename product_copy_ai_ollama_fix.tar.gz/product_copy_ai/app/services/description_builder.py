"""Deterministic fallback for a too-short LLM SEO description.

The fallback deliberately contains selection guidance, not additional product claims.
It is used only when the LLM repeatedly ignores the required 800-character minimum.
"""

from app.schemas import ProductInput
from app.services.guardrails import build_source_text


def build_fallback_seo_description(product: ProductInput) -> str | None:
    """Build an 800–1200 character, source-grounded description or return None.

    This is a last-resort fallback: the LLM remains responsible for the primary copy.
    Product facts are copied from input. Generic wording explains how buyers should
    verify the supplied parameters and explicitly avoids asserting compatibility.
    """
    if not product.name:
        return None

    name = product.name.rstrip(" .…")
    manufacturer = f" производства {product.manufacturer}" if product.manufacturer else ""
    description = (product.description or "").strip().rstrip(" .…")

    lead = f"{name}{manufacturer}"
    if description:
        # Avoid repeating the title if the source description already starts with it.
        if description.casefold().startswith(name.casefold()):
            intro = f"{description}."
        else:
            intro = f"{lead} — {description[0].lower() + description[1:]}."
    else:
        intro = f"{lead}."

    source = build_source_text(product).casefold()
    spec_items = [
        f"{key}: {value}"
        for key, value in product.specs.items()
        if value is not None and str(value).strip()
    ]
    if spec_items:
        specs_sentence = (
            "В предоставленных данных указаны следующие параметры: "
            + "; ".join(spec_items[:7])
            + "."
        )
    else:
        specs_sentence = "Дополнительные технические характеристики во входных данных не приведены."

    guidance: list[str] = []
    spec_keys = " ".join(
        key.casefold()
        for key, value in product.specs.items()
        if value is not None
    )
    if any(token in spec_keys for token in ("диапазон", "предел", "измерен")):
        guidance.append(
            "Указанный диапазон следует сопоставить с ожидаемым значением измеряемого параметра."
        )
    if any(token in spec_keys for token in ("точност", "погрешност", "класс")):
        guidance.append(
            "Класс точности или погрешность необходимо соотнести с требованиями измерительной задачи."
        )
    if any(token in spec_keys for token in ("присоедин", "резьб", "подключен")):
        guidance.append(
            "Обозначение присоединения нужно сверить с ответной частью узла монтажа."
        )
    if any(token in spec_keys for token in ("диаметр", "габарит", "размер")):
        guidance.append(
            "Указанные размеры следует проверить относительно доступного места установки."
        )
    if not guidance:
        guidance.append(
            "Каждую указанную характеристику следует сопоставить с требованиями объекта и документацией на оборудование."
        )

    missing_topics: list[str] = []
    topic_checks = [
        (("температур",), "температурный диапазон"),
        (("материал",), "материалы исполнения"),
        (("степень защит", "ip"), "степень защиты"),
        (("монтаж", "установ"), "способ монтажа"),
        (("комплект", "поставк"), "комплект поставки"),
        (
            ("рабочая сред", "измеряемая сред", "жидк", "газ"),
            "совместимость с измеряемой средой",
        ),
    ]
    for tokens, label in topic_checks:
        if not any(token in source for token in tokens):
            missing_topics.append(label)

    if missing_topics:
        missing_sentence = (
            "Во входных данных не указаны "
            + ", ".join(missing_topics[:5])
            + ". Эти сведения следует уточнить по паспорту производителя, "
            "если они важны для условий применения."
        )
    else:
        missing_sentence = (
            "Перед публикацией дополнительные условия эксплуатации и требования конкретного объекта "
            "следует сверить с паспортом производителя."
        )

    text = " ".join(
        [
            intro,
            specs_sentence,
            " ".join(guidance),
            "Эти пояснения описывают порядок первичной проверки сведений и не подтверждают "
            "совместимость изделия с конкретной системой или объектом.",
            missing_sentence,
            "Перед публикацией карточки и оформлением заказа рекомендуется сверить "
            "наименование и значения с документацией производителя.",
            "Сведения, которых нет в исходных данных, нельзя заменять предположениями или представлять как подтверждённые свойства товара.",
        ]
    )

    additions = [
        "Такой черновик предназначен для первичного оформления каталога и не заменяет "
        "технический паспорт или консультацию производителя.",
        "При сравнении предложений следует сопоставлять одноимённые параметры и проверять, "
        "что они указаны для одинаковых условий измерения и монтажа.",
    ]
    for sentence in additions:
        if len(text) >= 800:
            break
        text += " " + sentence

    if not 800 <= len(text) <= 1200:
        return None
    return text
